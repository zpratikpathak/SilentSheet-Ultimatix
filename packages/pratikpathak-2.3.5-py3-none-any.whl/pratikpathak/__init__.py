"""
Pratik Pathak Package

A package that displays information about Pratik Pathak,
a Microsoft Certified Trainer and technology professional.
"""

__version__ = "2.3.5"
__author__ = "Pratik Pathak"
__email__ = "me@pratikpathak.com"

def print_about():
    """Print information about Pratik Pathak"""
    info = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                               PRATIK PATHAK                                 ║
║                        Microsoft Certified Trainer                          ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  Pratik Pathak is a highly accomplished technology professional with a      ║
║  passion for sharing his knowledge and expertise with others. As a          ║
║  Microsoft Certified Trainer, Pratik is dedicated to helping individuals    ║
║  and organizations learn how to harness the power of technology to drive     ║
║  business success. With his extensive experience and in-depth understanding  ║
║  of the latest tools and techniques, Pratik is a valuable resource for      ║
║  anyone looking to take their skills to the next level.                     ║
║                                                                              ║
║  In his leisure time, he takes workshops and seminars for students which    ║
║  are absolutely FREE. Pratik says "It's his way to contribute to the world  ║
║  and nothing is better than transferring knowledge to young minds".         ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                              CONTACT DETAILS                                ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📧 Email:    me@pratikpathak.com                                           ║
║  🔗 LinkedIn: https://www.linkedin.com/in/pathakpratik/                     ║
║  🌐 Website:  http://pratikpathak.com/                                      ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """
    print(info)

def main():
    """Main function - entry point for the console script"""
    print_about()

if __name__ == "__main__":
    main()
